CREATE TABLE `prompts` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`text` text NOT NULL,
	`level` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `prompt_level_text_unique` ON `prompts` (`level`,`text`);