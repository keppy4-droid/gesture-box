import type { Metadata } from "next";
import "./globals.css";
export const metadata:Metadata={title:"ジェスチャーBOX | みんなで遊べるお題ゲーム",description:"普通250題・難しい350題。お題を引いて、身ぶりで伝えよう。ヒント・制限時間・オリジナルのお題追加にも対応。",icons:{icon:"/favicon.svg"}};
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>){return <html lang="ja"><body>{children}</body></html>}
