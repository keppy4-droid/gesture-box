import {promptDb} from "@/lib/prompt-db";
import {validatePrompt} from "@/lib/game";
import {builtins} from "@/lib/prompts";
export async function GET(){
 try{const result=await promptDb().prepare("SELECT id, text, level FROM prompts ORDER BY id").all();
 return Response.json({prompts:result.results.map((p:Record<string,unknown>)=>({...p,id:`custom-${p.id}`,category:"追加したお題"}))},{headers:{"Cache-Control":"no-store"}});
 }catch(e){console.error("Unable to load prompts",e);return Response.json({error:"追加したお題を読み込めませんでした。少し待って再試行してください。"},{status:503});}
}
export async function POST(request:Request){
 const origin=request.headers.get("origin");
 if(origin&&origin!==new URL(request.url).origin)return Response.json({error:"このサイトから追加してください。"},{status:403});
 let input;try{const raw=await request.text();if(raw.length>2000)throw new Error("お題が長すぎます。");input=validatePrompt(JSON.parse(raw));}catch(e){return Response.json({error:e instanceof Error?e.message:"お題を確認してください。"},{status:400});}
 if(builtins.some(p=>p.level===input.level&&p.text===input.text))return Response.json({error:"そのお題はすでに入っています。"},{status:409});
 try{
 const row=await promptDb().prepare("INSERT INTO prompts (text, level) VALUES (?, ?) ON CONFLICT(level, text) DO NOTHING RETURNING id, text, level").bind(input.text,input.level).first<{id:number;text:string;level:string}>();
 if(!row)return Response.json({error:"そのお題はすでに追加されています。"},{status:409});
 return Response.json({prompt:{...row,id:`custom-${row.id}`,category:"追加したお題"}},{status:201});
 }catch(e){console.error("Unable to save prompt",e);return Response.json({error:"保存できませんでした。入力は残っています。少し待って再試行してください。"},{status:503});}
}
