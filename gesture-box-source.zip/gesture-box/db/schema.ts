import {integer,sqliteTable,text,uniqueIndex} from "drizzle-orm/sqlite-core";
export const prompts=sqliteTable("prompts",{
 id:integer("id").primaryKey({autoIncrement:true}),
 text:text("text").notNull(),
 level:text("level").notNull(),
},table=>[uniqueIndex("prompt_level_text_unique").on(table.level,table.text)]);
