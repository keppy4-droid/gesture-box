import {env} from "cloudflare:workers";
export function promptDb(){if(!env.DB)throw new Error("Database unavailable");return env.DB;}
