# ジェスチャーBOX

ブラウザで遊べる日本語のジェスチャーゲームです。

## 機能

- ボタンでランダムにお題を表示。同じ難易度では一巡するまで重複しません。
- 普通：動物、家事・日常動作、スポーツ、職業、場所の250題。
- 難しい：「AがBしている」形式300題と、有名な観光地50題。
- ヒントボタンで手がかりを表示。お題を隠さず、並べて確認できます。
- 制限時間なし、または5〜600秒のタイマー。
- オリジナルのお題を追加し、Cloudflare D1に保存。
- スマートフォン・パソコンに対応。

## 開発

Node.js 22.13以降とnpmを使用します。

```sh
npm run install:ci
npm run build
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_watery_marten_broadcloak.sql
npm run dev
```

上記のマイグレーション適用は初回だけ実行します。ローカル開発URLは起動ログに表示されます。

## 構成

- `app/page.tsx`：ゲーム画面・タイマー・ヒント表示
- `lib/prompts.ts`：600個のお題
- `lib/hints.ts`：ヒント生成
- `lib/game.ts`：抽選・入力チェック
- `app/api/prompts/route.ts`：お題の保存・読み込み
- `db/schema.ts`、`drizzle/`：データベース定義

React / TypeScript / Vinext / Cloudflare Workers / D1を使用しています。
Sitesでの運用設定は `.openai/hosting.json` にあります。他の環境へ公開する場合は、その環境のD1と認証・公開範囲を設定してください。GitHubへのコード保存だけではサイトは更新されません。サーバーとデータベースを使用するため、GitHub Pagesだけでは全機能を実行できません。

実行環境の詳細は [スターターの説明](docs/starter.md) を参照してください。

## このソースの状態

ヒント表示時にお題を隠さない修正と、観光地を難しいへ移した変更を含みます。これらはローカルで型チェック・ビルド・お題データの検証を通過しています。現在の公開サイトにはまだ反映されていません。
